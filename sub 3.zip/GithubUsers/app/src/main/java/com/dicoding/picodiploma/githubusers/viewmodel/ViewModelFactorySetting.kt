package com.dicoding.picodiploma.githubusers.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.githubusers.PreferenceSetting
import java.lang.IllegalArgumentException

class ViewModelFactorySetting (private var preference: PreferenceSetting) : ViewModelProvider.NewInstanceFactory(){
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PreferenceSettingViewModel::class.java)) {
            return PreferenceSettingViewModel(preference) as T
        }
        throw IllegalArgumentException("Unknown ViewModel Class: " + modelClass.name)
    }
}