package com.dicoding.picodiploma.githubusers.repository

import android.app.Application
import androidx.lifecycle.LiveData
import com.dicoding.picodiploma.githubusers.data.database.DAO
import com.dicoding.picodiploma.githubusers.data.database.DatabaseUser
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class UserLikedRepository (application: Application){
    private val mDAO: DAO
    private val executorService:ExecutorService = Executors.newSingleThreadExecutor()

    init {
        val database = DatabaseUser.databaseGet(application)
        mDAO = database.dao()
    }

    fun userLikedGet(): LiveData<List<EntitasLikedUser>> = mDAO.userLikedGet()

    fun insert(user: EntitasLikedUser) {
        executorService.execute { mDAO.userLikedInsert(user) }
    }

    fun likedDelete(id: Int) {
        executorService.execute { mDAO.userLikedDelete(id) }
    }
}