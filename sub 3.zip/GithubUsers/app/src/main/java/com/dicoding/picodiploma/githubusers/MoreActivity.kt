package com.dicoding.picodiploma.githubusers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubusers.adapter.PageSectionAdapter
import com.dicoding.picodiploma.githubusers.data.api.ItemsItem
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import com.dicoding.picodiploma.githubusers.databinding.ActivityMoreBinding
import com.dicoding.picodiploma.githubusers.viewmodel.MoreViewModel
import com.dicoding.picodiploma.githubusers.viewmodel.UserLikedViewModel
import com.dicoding.picodiploma.githubusers.viewmodel.ViewModelFactory
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MoreActivity: AppCompatActivity() {
    private lateinit var binding: ActivityMoreBinding
    private lateinit var moreViewModel: MoreViewModel
    private var followerUrl: String = ""
    private var repoUrl: String = ""
    private lateinit var userLikedGet: UserLikedViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoreBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "Detail User"

        val searcHing = intent.getParcelableExtra<ItemsItem>(DETAIL_USER) as EntitasLikedUser

        moreViewModel = ViewModelProvider(this@MoreActivity).get(MoreViewModel::class.java)
        moreViewModel.isloading.observe(this, {
            showLoading(it)
        })
        moreViewModel.moreUserSet(searcHing.url)
        moreViewModel.moreUsersGet().observe(this, {
            binding.apply {
                Glide.with(this@MoreActivity)
                    .load(it.ava)
                    .into(binding.imgItemPhoto)
                UserName.text = it.login
                name.text = it.name
                location.text = it.location
                company.text = it.company
            }
            followerUrl = it.followers_url
            totFollowerUrl(followerUrl)
            repoUrl = it.repos_url
            totRepoUrl(repoUrl)
        })
        moreViewModel.followingCountSet(searcHing.login!!)
        moreViewModel.followingTotGet().observe(this, {
            binding.following.text = "$it Following"
        })

        val pageSectionAdapter = PageSectionAdapter(this)
        pageSectionAdapter.username = searcHing.login
        val viewPager: ViewPager2 = binding.viewPager
        binding.viewPager.adapter = pageSectionAdapter
        val tab: TabLayout = binding.tab
        TabLayoutMediator(binding.tab, binding.viewPager){tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        userLikedGet = obtainUserLikedViewModel(this@MoreActivity)

        isLikedSet(searcHing.isLiked)
        binding.faveIcon.setOnClickListener {
            if (searcHing.isLiked == false) {
                searcHing.isLiked = true
                userLikedGet.userInsert(searcHing)
                isLikedSet(searcHing.isLiked)
                Toast.makeText(this@MoreActivity, "Your Favorite", Toast.LENGTH_SHORT).show()
            }
            else if (searcHing.isLiked == true) {
                searcHing.isLiked = false
                userLikedGet.likedDelete(searcHing.id)
                isLikedSet(searcHing.isLiked)
                Toast.makeText(this@MoreActivity, "Not Your Favorite", Toast.LENGTH_SHORT).show()
            }
        }
        supportActionBar?.elevation = 0f
    }

    private fun isLikedSet(state: Boolean){
        if(state) {
            binding.faveIcon.setImageResource(R.drawable.ic_baseline_favorite_24)
        }
        else {
            binding.faveIcon.setImageResource((R.drawable.ic_baseline_favorite_border_24))
        }
    }

    private fun obtainUserLikedViewModel(activity: AppCompatActivity) : UserLikedViewModel {
        val factory = ViewModelFactory.newInstacne(activity.application)
        return ViewModelProvider(activity, factory).get(UserLikedViewModel::class.java)
    }

    fun totFollowerUrl(followerUrl : String) {
        moreViewModel.followerCountSet(followerUrl)
        moreViewModel.followerTotGet().observe(this, {
            binding.follower.text = "$it Followers"
        })
    }

    fun totRepoUrl(repoUrl : String) {
        moreViewModel.repoCountSet(repoUrl)
        moreViewModel.repoTotGet().observe(this, {
            binding.repository.text = "$it Repositories"
        })
    }

    private fun showLoading(state: Boolean) { binding.progressBar.visibility = if (state == true) View.VISIBLE else View.GONE }

    companion object {
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )
        const val DETAIL_USER = "detail_user"
        private val TAG = MoreActivity::class.java.simpleName
    }

}