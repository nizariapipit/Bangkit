package com.dicoding.picodiploma.githubusers.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.githubusers.data.api.ApiConfig
import com.dicoding.picodiploma.githubusers.data.api.ResponseUsers
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import retrofit2.Call
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val listUsers = MutableLiveData<List<EntitasLikedUser>>()

    fun setUser(users: String) {
        val asyncClient = ApiConfig.getApiService().searchQueryGet(users)
        asyncClient.enqueue(object : retrofit2.Callback<ResponseUsers> {
            override fun onResponse(
                call: Call<ResponseUsers>,
                response: Response<ResponseUsers>
            ) {
                if(response.isSuccessful) {
                    val listItemUser = ArrayList<EntitasLikedUser>()
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val listItem = responseBody.items
                        for (zero in listItem) {
                            val listAdapter = EntitasLikedUser(zero.id, zero.login, zero.url, zero.avatarUrl, isLiked = false)
                            listItemUser.add(listAdapter)
                        }
                        listUsers.postValue(listItemUser)
                    }
                }
                else {
                    Log.e(TAG,"onFailure: ${response.message()}" )
                }
            }
            override fun onFailure(call: Call<ResponseUsers>, t: Throwable) {

            }
        })
    }

    fun getUser(): LiveData<List<EntitasLikedUser>> {
        return listUsers
    }

    companion object {
        private val TAG = FollowingViewModel::class.java.simpleName
    }
}