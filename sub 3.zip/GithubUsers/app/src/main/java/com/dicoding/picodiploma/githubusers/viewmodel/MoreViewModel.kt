package com.dicoding.picodiploma.githubusers.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.githubusers.data.api.ApiConfig
import com.dicoding.picodiploma.githubusers.data.api.UserDataObject
import com.dicoding.picodiploma.githubusers.data.api.UserDetail
import com.loopj.android.http.AsyncHttpClient
import com.loopj.android.http.AsyncHttpResponseHandler
import cz.msebera.android.httpclient.Header
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import kotlin.Exception

class MoreViewModel : ViewModel() {

    private val _isLoading = MutableLiveData<Boolean>()
    val isloading: LiveData<Boolean> = _isLoading

    private val _moreUsers = MutableLiveData<UserDetail>()
    val moreUsers : LiveData<UserDetail> = _moreUsers

    private val _totFollowerUrl = MutableLiveData<String>()
    val totFollowerUrl : LiveData<String> = _totFollowerUrl

    private val _totFollowingUrl = MutableLiveData<String>()
    val totFollowingUrl : LiveData<String> = _totFollowingUrl

    private val _totRepoUrl = MutableLiveData<String>()
    val totRepoUrl : LiveData<String> = _totRepoUrl

    fun moreUserSet(users: String) {
        _isLoading.value = true
        val asyncClient = AsyncHttpClient()
        asyncClient.addHeader("Authorization", "token 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")
        asyncClient.addHeader("User-Agent", "request")
        asyncClient.get(users, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray
            ) {
                val result = String(responseBody)
                Log.d(TAG, result)
                try {
                    val jsonObject = JSONObject(result)
                    val login = jsonObject.getString("login")
                    val name = jsonObject.getString("name")
                    val ava = jsonObject.getString("avatar_url")
                    val followerUrl = jsonObject.getString("followers_url")
                    val location = jsonObject.getString("location")
                    val company = jsonObject.getString("company")
                    val repo_url = jsonObject.getString("repos_url")

                    val newInstance = UserDetail(login, name, company, location, repo_url, followerUrl, ava)
                    _moreUsers.postValue(newInstance)
                    _isLoading.value = false
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d("onFailure: ", error?.message.toString())
            }
        })
    }

    fun followerCountSet(followerUrl: String) {
        val followerAccess = AsyncHttpClient()
        followerAccess.get(followerUrl, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>,
                responseBody: ByteArray,
            ) {
                val result = String(responseBody)
                try {
                    val jsonArray = JSONArray(result)
                    val jsonArraySize = jsonArray.length()
                    _totFollowerUrl.postValue(jsonArraySize.toString())
                }
                catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?,
            ) {
                when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d("onFailure: ", error?.message.toString())
            }

        })
        followerAccess.addHeader("Authorization", "token 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")
        followerAccess.addHeader("User-Agent", "request")
    }

    fun followingCountSet(followingUrl : String) {
        val followingAccess = ApiConfig.getApiService().usersFollowingGet(followingUrl)
        followingAccess.enqueue(object : Callback<List<UserDataObject>> {
            override fun onResponse(
                call: Call<List<UserDataObject>>,
                response: Response<List<UserDataObject>>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    val jum = responseBody.size
                    _totFollowingUrl.postValue(jum.toString())
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<List<UserDataObject>>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun repoCountSet (repo : String) {
        val repoAccess = AsyncHttpClient()
        repoAccess.get(repo, object : AsyncHttpResponseHandler() {
            override fun onSuccess(
                statusCode: Int,
                headers: Array<out Header>,
                responseBody: ByteArray
            ) {
                val result = String(responseBody)
                try {
                    val jsonArray = JSONArray(result)
                    Log.d(TAG, "Total Repo ${jsonArray.length()}")
                    val jsonArraySize = jsonArray.length()
                    _totRepoUrl.postValue(jsonArraySize.toString())
                }
                catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            override fun onFailure(
                statusCode: Int,
                headers: Array<out Header>?,
                responseBody: ByteArray?,
                error: Throwable?
            ) {
                when (statusCode) {
                    401 -> "$statusCode : Bad Request"
                    403 -> "$statusCode : Forbidden"
                    404 -> "$statusCode : Not Found"
                    else -> "$statusCode : ${error?.message}"
                }
                Log.d("onFailure: ", error?.message.toString())
            }
        })
        repoAccess.addHeader("Authorization", "token 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")
        repoAccess.addHeader("User-Agent", "request")
    }

    fun moreUsersGet(): LiveData<UserDetail> {
        return _moreUsers
    }

    fun followerTotGet(): LiveData<String> {
        return _totFollowerUrl
    }

    fun followingTotGet(): LiveData<String> {
        return _totFollowingUrl
    }

    fun repoTotGet(): LiveData<String> {
        return _totRepoUrl
    }

    companion object {
        private val TAG = MoreViewModel::class.java.simpleName
    }
}