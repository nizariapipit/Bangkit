package com.dicoding.picodiploma.githubusers.data.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser

@Dao
interface DAO {
    @Query("select * from user_like where isLiked = 1")
    fun userLikedGet(): LiveData<List<EntitasLikedUser>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun userLikedInsert(entitasLikedUser: EntitasLikedUser)

    @Query("delete from user_like where id=:id")
    fun userLikedDelete(id:Int)
}