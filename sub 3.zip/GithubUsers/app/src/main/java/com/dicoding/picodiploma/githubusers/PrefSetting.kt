package com.dicoding.picodiploma.githubusers

import android.content.Context
import android.os.Bundle
import android.widget.CompoundButton
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.githubusers.viewmodel.PreferenceSettingViewModel
import com.dicoding.picodiploma.githubusers.viewmodel.ViewModelFactorySetting
import com.google.android.material.switchmaterial.SwitchMaterial

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class PrefSetting : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.setting_pref)

        val switchTheme = findViewById<SwitchMaterial>(R.id.switch_theme)

        val preference = PreferenceSetting.newInstance(dataStore)
        val preferenceSettingViewModel = ViewModelProvider(this, ViewModelFactorySetting(preference)).get(PreferenceSettingViewModel::class.java)
        preferenceSettingViewModel.themeSettingGet().observe(this, {isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                switchTheme.isChecked = true
            }
            else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                switchTheme.isChecked = false
            }
        })
        switchTheme.setOnCheckedChangeListener {_: CompoundButton?, isChecked:Boolean ->
            preferenceSettingViewModel.themeSettingSave(isChecked)
        }
    }
}