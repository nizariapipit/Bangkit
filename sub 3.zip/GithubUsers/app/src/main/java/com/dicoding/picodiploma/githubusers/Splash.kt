package com.dicoding.picodiploma.githubusers

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatDelegate
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.ViewModelProvider
import com.dicoding.picodiploma.githubusers.viewmodel.PreferenceSettingViewModel
import com.dicoding.picodiploma.githubusers.viewmodel.ViewModelFactorySetting

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")
class Splash : AppCompatActivity() {

    companion object{
        const val mil: Long = 500
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler().postDelayed({
            val berpindah = Intent(this, MainActivity::class.java)
            startActivity(berpindah)
            finish()
        }, mil)

        val preference = PreferenceSetting.newInstance(dataStore)
        val preferenceSettingViewModel = ViewModelProvider(this, ViewModelFactorySetting(preference)).get(PreferenceSettingViewModel::class.java)
        preferenceSettingViewModel.themeSettingGet().observe(this, { activeDarkMode: Boolean ->
            if (activeDarkMode) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            }
            else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        })
    }
}