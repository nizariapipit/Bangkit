package com.dicoding.picodiploma.githubusers.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubusers.data.api.UserFfAdapter
import com.dicoding.picodiploma.githubusers.databinding.FollAdapterBinding

class FollAdapter(private val listFoll : ArrayList<UserFfAdapter>) : RecyclerView.Adapter<FollAdapter.ListViewHolder>(){
    class ListViewHolder (var binding : FollAdapterBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ListViewHolder {
        val bindLayer = FollAdapterBinding.inflate(LayoutInflater.from(viewGroup.context), viewGroup, false)
        return ListViewHolder(bindLayer)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (login, avaUrl) = listFoll[position]
        holder.apply {
            Glide.with(itemView.context)
                .load(avaUrl)
                .circleCrop()
                .into(binding.imgItemPhoto)
            binding.tvItemName.text = login
        }
    }

    override fun getItemCount(): Int = listFoll.size
}