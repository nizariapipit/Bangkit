package com.dicoding.picodiploma.githubusers

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.githubusers.adapter.ListUserAdapter
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import com.dicoding.picodiploma.githubusers.databinding.ActivityMainBinding
import com.dicoding.picodiploma.githubusers.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel
    private lateinit var searchUserAdapter: ListUserAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(false)

        supportActionBar?.title = "GitHub Users"

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        mainViewModel = ViewModelProvider(this@MainActivity).get(MainViewModel::class.java)

        setListUserAdapter()
        mainViewModel.getUser().observe(this, { itemUser ->
            searchUserAdapter.dataSet(itemUser)
            showLoading(false)
        })
    }

    private fun showLoading(state: Boolean) { binding.progressBar.visibility = if (state == true) View.VISIBLE else View.GONE }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView =  menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                getDataUsersFromApi(query)
                return true
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }

    private fun setListUserAdapter() {
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        searchUserAdapter = ListUserAdapter()
        searchUserAdapter.notifyDataSetChanged()
        binding.rvUser.adapter = searchUserAdapter
        searchUserAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: EntitasLikedUser) {
                detailforlUser(data)
            }
        })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        modeSet(item.itemId)
        return super.onOptionsItemSelected(item)
    }

    private fun modeSet(selectedMode: Int) {
        when (selectedMode) {
            R.id.settings -> {
                moveToSetting()
            }
            R.id.liked_user -> {
                moveToFaveUser()
            }
        }
    }

    private fun detailforlUser(data: EntitasLikedUser){
        val detailUser = Intent(this@MainActivity, MoreActivity::class.java)
        detailUser.putExtra(MoreActivity.DETAIL_USER, data)
        startActivity(detailUser)
    }

    private fun getDataUsersFromApi(query: String) {
        if (query.isEmpty()) return
        showLoading(true)
        mainViewModel.setUser(query)
    }

    private fun moveToSetting() {
        startActivity(Intent(this@MainActivity, PrefSetting::class.java))
    }

    private fun moveToFaveUser() {
        startActivity(Intent(this@MainActivity, UserFaveActivity::class.java))
    }

    companion object {
        private const val TAG = "MainActivity"
    }

}
