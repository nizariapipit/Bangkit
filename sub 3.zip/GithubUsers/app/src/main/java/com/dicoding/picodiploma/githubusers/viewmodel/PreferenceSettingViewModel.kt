package com.dicoding.picodiploma.githubusers.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.dicoding.picodiploma.githubusers.PreferenceSetting
import kotlinx.coroutines.launch

class PreferenceSettingViewModel (private val preference: PreferenceSetting) : ViewModel(){
    fun themeSettingGet(): LiveData<Boolean> {
        return preference.themeSettingGet().asLiveData()
    }

    fun themeSettingSave(isDarkModeActive: Boolean) {
        viewModelScope.launch {
            preference.themeSettingSave(isDarkModeActive)
        }
    }
}