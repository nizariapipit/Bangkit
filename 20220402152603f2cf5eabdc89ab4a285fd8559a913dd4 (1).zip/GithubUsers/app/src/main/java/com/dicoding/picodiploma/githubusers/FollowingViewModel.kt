package com.dicoding.picodiploma.githubusers

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel : ViewModel(){

    private val rvFollowing = MutableLiveData<ArrayList<UserFfAdapter>>()
    private val  _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun followingSet(username: String?) {
        _isLoading.value = true
        val followingGets = ApiConfig.getApiService().usersFollowingGet(username)
        followingGets.enqueue(object : Callback<List<UserDataObject>> {
            override fun onResponse(
                call: Call<List<UserDataObject>>,
                response: Response<List<UserDataObject>>
            ) {
                val responseBody = response.body()
                if (response.isSuccessful && responseBody != null) {
                    val listFoll = ArrayList<UserFfAdapter>()
                    for (zero in responseBody) {
                        val follAdapter = UserFfAdapter(zero.login, zero.avatarUrl)
                        listFoll.add(follAdapter)
                    }
                    rvFollowing.postValue(listFoll)
                    _isLoading.value = false
                }
                else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<UserDataObject>>, t: Throwable) {
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun followingGet(): LiveData<ArrayList<UserFfAdapter>> {
        return rvFollowing
    }

    companion object {
        private val TAG = FollowingViewModel::class.java.simpleName
    }
}