package com.dicoding.picodiploma.githubusers

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubusers.databinding.ItemRowUserBinding

class ListUserAdapter(private val data : List<ItemsItem>) : RecyclerView.Adapter<ListUserAdapter.ListViewHolder>(){
    private var onItemClickCallback: OnItemClickCallback? = null

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val(login,_,avatarUrl) = data[position]
        holder.apply {
            Glide.with(itemView.context)
                .load(avatarUrl)
                .circleCrop()
                .into(binding.imgItemPhoto)
            binding.tvItemName.text = login
            itemView.setOnClickListener { onItemClickCallback?.onItemClicked(data[adapterPosition]) }
        }
    }

    override fun getItemCount(): Int = data.size

    class ListViewHolder(val binding: ItemRowUserBinding) : RecyclerView.ViewHolder(binding.root)

    interface OnItemClickCallback {
        fun onItemClicked(data : ItemsItem)
    }
}



