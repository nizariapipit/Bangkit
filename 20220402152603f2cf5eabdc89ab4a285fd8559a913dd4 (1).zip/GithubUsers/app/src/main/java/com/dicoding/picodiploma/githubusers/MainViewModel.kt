package com.dicoding.picodiploma.githubusers

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import retrofit2.Call
import retrofit2.Response

class MainViewModel : ViewModel() {

    private val listUsers = MutableLiveData<List<ItemsItem>>()

    fun setUser(users: String) {
        val asyncClient = ApiConfig.getApiService().searchQueryGet(users)
        asyncClient.enqueue(object : retrofit2.Callback<ResponseUsers> {
            override fun onResponse(
                call: Call<ResponseUsers>,
                response: Response<ResponseUsers>
            ) {
                if(response.isSuccessful) {
                    val listItemUser = ArrayList<ItemsItem>()
                    val responseBody = response.body()
                    if (responseBody != null) {
                        val listItem = responseBody.items
                        for (zero in listItem) {
                            val listAdapter = ItemsItem(zero.login, zero.url, zero.avatarUrl)
                            listItemUser.add(listAdapter)
                        }
                        listUsers.postValue(listItemUser)
                    }
                }
                else {
                    Log.e(TAG,"onFailure: ${response.message()}" )
                }
            }
            override fun onFailure(call: Call<ResponseUsers>, t: Throwable) {

            }
        })
    }

    fun getUser(): LiveData<List<ItemsItem>> {
        return listUsers
    }

    companion object {
        private val TAG = FollowingViewModel::class.java.simpleName
    }
}