package com.dicoding.picodiploma.githubusers

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.View
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.githubusers.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        showLoading(false)

        supportActionBar?.title = "GitHub Users"

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        mainViewModel = ViewModelProvider(this@MainActivity).get(MainViewModel::class.java)

        mainViewModel.getUser().observe(this, { userItems ->
            setListUserAdapter(userItems)
        })
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView =  menu.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                getDataUsersFromApi(query)
                return true
            }
            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }

    private fun setListUserAdapter(users: List<ItemsItem>) {
        val listUserItem = ArrayList<ItemsItem>()
        for (zero in users) {
            val  listAdapt= ItemsItem(zero.login, zero.url, zero.avatarUrl)
            listUserItem.add(listAdapt)
        }
        val adapter = ListUserAdapter(listUserItem)
        binding.rvUser.adapter = adapter
        adapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(zero: ItemsItem) {
                detailforlUser(zero)
            }
        })
        showLoading(false)
    }

    private fun detailforlUser(users: ItemsItem){
        val detailforlUser = Intent(this@MainActivity, MoreActivity::class.java)
        detailforlUser.putExtra(MoreActivity.DETAIL_USER, users)
        startActivity(detailforlUser)
    }

    private fun getDataUsersFromApi(query: String) {
        if (query.isEmpty()) return
        showLoading(true)
        mainViewModel.setUser(query)
    }

}
