package com.dicoding.picodiploma.githubusers

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.githubusers.databinding.FragmentFollowerBinding

class FollowerFragment() : Fragment() {
    private lateinit var binding: FragmentFollowerBinding
    private lateinit var followerViewModel: FollowerViewModel

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        }
        else {
            binding.progressBar.visibility = View.GONE
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val username = arguments?.getString(ARG_USERNAME)
        followerViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(FollowerViewModel::class.java)
        followerViewModel.apply { showLoading(false) }
        followerViewModel.followerSet(username)
        followerViewModel.followerGet().observe(viewLifecycleOwner, {rvFollower ->
            followerAdapterSet(rvFollower)
        })
    }

    private fun followerAdapterSet(listFoll : ArrayList<UserFfAdapter>) {
        binding.rvFollower.setHasFixedSize(true)
        Log.d(TAG, "onSuccess ${listFoll.size}")
        val layoutManager = LinearLayoutManager(activity)
        binding.rvFollower.layoutManager = layoutManager
        val follAdapter = FollAdapter(listFoll)
        binding.rvFollower.adapter = follAdapter
    }

    companion object {
        private val TAG = MoreActivity::class.java.simpleName
        private const val ARG_USERNAME = "username"

        fun newInstace(username: String?): FollowerFragment {
            val fragment = FollowerFragment()
            val bundle = Bundle()
            bundle.putString(ARG_USERNAME, username)
            fragment.arguments = bundle
            return fragment
        }
    }
}
