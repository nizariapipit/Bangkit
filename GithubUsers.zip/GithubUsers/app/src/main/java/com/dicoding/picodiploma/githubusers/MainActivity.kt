package com.dicoding.picodiploma.githubusers

import android.content.Intent
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.picodiploma.githubusers.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var rv_user: RecyclerView
    private val list = ArrayList<Users>()
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.title = "GitHub Users"

        rv_user = findViewById(R.id.rv_user)
        rv_user.setHasFixedSize(true)

        list.addAll(listUsers)
        showRecyclerList()

    }

    private val listUsers: ArrayList<Users>
        get() {
            val dataUsername = resources.getStringArray(R.array.username)
            val dataName = resources.getStringArray(R.array.name)
            val dataFollower = resources.getStringArray(R.array.followers)
            val dataLocation = resources.getStringArray(R.array.location)
            val dataRepository = resources.getStringArray(R.array.repository)
            val dataCompany = resources.getStringArray(R.array.company)
            val dataFollowing = resources.getStringArray(R.array.following)
            val dataAvatar = resources.obtainTypedArray(R.array.avatar)
            val listUsers = ArrayList<Users>()
            for (i in dataUsername.indices) {
                val user = Users(dataUsername[i], dataName[i], dataLocation[i], dataRepository[i], dataCompany[i], dataFollower[i], dataFollowing[i], dataAvatar.getResourceId(i, -1))
                listUsers.add(user)
            }
            return listUsers
        }


    private fun showRecyclerList() {
        val listUserAdapter = ListUserAdapter(list)
        rv_user.adapter = listUserAdapter
        if (applicationContext.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            rv_user.layoutManager = GridLayoutManager(this, 2)
        } else {
            rv_user.layoutManager = LinearLayoutManager(this)
        }

        listUserAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Users) {
                detailforlUser(data)
            }
        })
    }

    private fun detailforlUser(user: Users){
        val detailforlUser = Intent(this@MainActivity, MoreActivity::class.java)
        detailforlUser.putExtra(MoreActivity.DETAIL_USER, user)
        startActivity(detailforlUser)
    }


}
