package com.dicoding.picodiploma.githubusers

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Users(
    val Username: String,
    val name: String,
    val location: String,
    val Repository: String,
    val company: String,
    val followers: String,
    val following: String,
    val avatar: Int
) :Parcelable