package com.dicoding.picodiploma.githubusers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class MoreActivity: AppCompatActivity() {

    companion object {
        const val DETAIL_USER = "detail_user"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more)

        supportActionBar?.title = "Detail User"

        val detail = intent.getParcelableExtra<Users>(DETAIL_USER) as Users

        val avatar : ImageView = findViewById(R.id.img_item_photo)
        avatar.setImageResource(detail.avatar)

        val userName : TextView = findViewById(R.id.UserName)
        userName.text = detail.Username

        val  name : TextView = findViewById(R.id.name)
        name.text = detail.name

        val location : TextView = findViewById(R.id.location)
        location.text = detail.location

        val repository : TextView = findViewById(R.id.repository)
        repository.text = detail.Repository

        val company : TextView = findViewById(R.id.company)
        company.text = detail.company

        val follower : TextView = findViewById(R.id.followers)
        follower.text = detail.followers

        val following : TextView = findViewById(R.id.following)
        following.text = detail.following
    }
}